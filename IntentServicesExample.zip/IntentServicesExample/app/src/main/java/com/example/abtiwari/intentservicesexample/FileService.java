package com.example.abtiwari.intentservicesexample;


import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class FileService extends IntentService {

    public static final String TRANSACTION_DONE = "SERVICE_DONE";

    public FileService() {
        super(FileService.class.getName());
    }

    public FileService(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        Log.e("FileService", "Service Started");

        String url = intent.getStringExtra("URL");

        downloadFile(url);

        Log.e("FileService", "Service Stopped");

        Intent i = new Intent(TRANSACTION_DONE);
        FileService.this.sendBroadcast(i);

    }

    private void downloadFile(String url) {
        String filename = "file_1";
        try {
            FileOutputStream fileOutputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            URL fileURL = new URL(url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) fileURL.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            byte[] buffer = new byte[1024];
            int bufferLength = 0;

            while ((bufferLength = inputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, bufferLength);
            }
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
