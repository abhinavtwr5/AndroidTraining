package com.example.abtiwari.conversionapp;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Button;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    EditText value_1;
    Spinner unitSpinner_1, unitSpinner_2;
    TextView unit_1, unit_2;
    Button convert;
    UnitConverter obj = new UnitConverter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        value_1 = (EditText) findViewById(R.id.value);
        convert = (Button) findViewById(R.id.button);

        addItemsToSpinners();




        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double value = Double.parseDouble(value_1.getText().toString());
                obj.setValue(value);
                String unit1= unitSpinner_1.getSelectedItem().toString();
                String unit2= unitSpinner_2.getSelectedItem().toString();
                obj.setUnit1(unit1);
                obj.setUnit2(unit2);
                DecimalFormat df=new DecimalFormat("#.000");

                obj.calculation();
                unit_1 = (TextView) findViewById(R.id.unit_1);
                unit_2 = (TextView) findViewById(R.id.unit_2);

                unit_1.setText(value_1.getText().toString() + " " + obj.getUnit1());

                unit_2.setText(df.format(obj.getValue()) + " " + obj.getUnit2());

            }
        });


    }

    public void addItemsToSpinners() {
        unitSpinner_1 = (Spinner) findViewById(R.id.spinner_1);
        ArrayAdapter<CharSequence> spinnerAdapter_1 = ArrayAdapter.createFromResource(this, R.array.conversion_types, android.R.layout.simple_spinner_item);
        spinnerAdapter_1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        unitSpinner_2 = (Spinner) findViewById(R.id.spinner_2);
        ArrayAdapter<CharSequence> spinnerAdapter_2 = ArrayAdapter.createFromResource(this, R.array.conversion_types, android.R.layout.simple_spinner_item);
        spinnerAdapter_2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        unitSpinner_1.setAdapter(spinnerAdapter_1);
        unitSpinner_2.setAdapter(spinnerAdapter_2);

    }
}


