package com.example.abtiwari.conversionapp;


import android.icu.text.DecimalFormat;

public class UnitConverter {

     double value;
     String unit1,unit2;


    public UnitConverter() {
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getUnit1() {
        return unit1;
    }

    public void setUnit1(String unit1) {
        this.unit1 = unit1;
    }

    public String getUnit2() {
        return unit2;
    }

    public void setUnit2(String unit2) {
        this.unit2 = unit2;
    }

    public void calculation()
    {
        double temp=0;


        switch (unit1)
        {
            case "meters" : temp=value;
                break;

            case "yards" : temp=0.9144*value;
                break;

            case "foots" : temp=0.3048*value;
                break;

            case "inches" : temp=0.0254*value;
                break;

            default: temp=0;
                break;

        }

        switch (unit2)
        {
            case "meters" : value=temp;
                break;

            case "yards" : value=1.09361*temp;
                break;

            case "foots" : value=3.28084*temp;
                break;

            case "inches" : value=39.3701*temp;
                break;

            default: value=0;
                break;
        }



    }


}
