package com.example.abtiwari.beatbox;


import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BeatBox {

    private final String SOUND_FOLDER = "sample_sounds";
    private List<Sound> mSoundList=new ArrayList<>();
    private AssetManager mAssets;
    private SoundPool mSoundPool;

    public BeatBox(Context context) {
        mAssets = context.getAssets();
        mSoundPool = new SoundPool(5, AudioManager.STREAM_MUSIC,0);
        loadSounds();
    }

    private void loadSounds() {
        try {
            String[] soundFiles=mAssets.list(SOUND_FOLDER);
            Log.i("LIST","TOTAL "+soundFiles.length);
            for(String filename : soundFiles)
            {
                String filePath = SOUND_FOLDER+"/"+filename;
                Sound sound = new Sound(filePath);
                load(sound);
                mSoundList.add(sound);
            }
            Log.i("LIST_LENGTH","TOTAL "+mSoundList.size());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void load(Sound sound)
    {
        try {
            AssetFileDescriptor afd = mAssets.openFd(sound.getAssetPath());
            Integer soundId = mSoundPool.load(afd,1);
            sound.setSoundId(soundId);
        }
        catch(Exception e)
        {
            return;
        }
    }

    public void play(Sound sound) {
        Integer soundId = sound.getSoundId();
        if(soundId == null)
        {
            return;
        }
        mSoundPool.play(soundId,1.0f,1.0f,1,0,1.0f);

    }

    public void release() {
        mSoundPool.release();
    }

    public List<Sound> getSoundList() {
        return mSoundList;
    }

}
