package com.example.abtiwari.intentobjectexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getUserName(View view) {

        PersonDetails person_1 = new PersonDetails("Abhinav",23,"Male");

        int result=1;

        Intent getUserNameintent = new Intent(this,SecondActivity.class);
        getUserNameintent.putExtra("callingActivity","MainActivity");
        getUserNameintent.putExtra("personDetails", person_1);

        startActivityForResult(getUserNameintent,result);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        String name="";
        TextView txt = (TextView)findViewById(R.id.Usename_Edit);

        txt.setText("Username : ");

        name=data.getStringExtra("UserName");

        txt.append(' '+ name);



    }
}
