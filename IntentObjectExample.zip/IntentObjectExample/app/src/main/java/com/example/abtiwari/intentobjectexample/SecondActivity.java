package com.example.abtiwari.intentobjectexample;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        Intent getActivityIntent = getIntent();
        String activityName=getActivityIntent.getExtras().getString("callingActivity");
        PersonDetails p = (PersonDetails) getActivityIntent.getSerializableExtra("personDetails");

        TextView setActivityText = (TextView)findViewById(R.id.activity_text);
        setActivityText.append(' '+activityName);
        TextView setPersonDetails = (TextView)findViewById(R.id.activity_text_1);
        setPersonDetails.append("\n\n"+p.getName()+ ' '+p.getAge()+' '+p.getGender());

    }

    public void sendUserName(View view) {

        EditText userNameEdit= (EditText)findViewById(R.id.get_text);
        String userName = String.valueOf(userNameEdit.getText());

        Intent intent2=new Intent(this,MainActivity.class);
        intent2.putExtra("UserName",userName);

        setResult(RESULT_OK,intent2);
        finish();



    }
}

