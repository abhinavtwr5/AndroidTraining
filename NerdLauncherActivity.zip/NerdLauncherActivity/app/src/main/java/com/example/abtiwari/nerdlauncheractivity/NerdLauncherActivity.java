package com.example.abtiwari.nerdlauncheractivity;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class NerdLauncherActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() {
        Fragment fragment = NerdLauncherFragment.newInstance();
        Log.i("SET_ARGUMENTS_CHECK",fragment.getArguments().getString("SET_ARGUMENTS_CHECK"));
        return fragment;
    }

}
