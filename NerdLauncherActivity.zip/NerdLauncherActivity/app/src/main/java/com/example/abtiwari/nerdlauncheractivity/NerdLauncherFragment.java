package com.example.abtiwari.nerdlauncheractivity;


import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NerdLauncherFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private ActivityAdapter mActivityAdapter;

    public static NerdLauncherFragment newInstance() {
        NerdLauncherFragment nerdLauncherFragment = new NerdLauncherFragment();
        Bundle args = new Bundle();
        args.putString("SET_ARGUMENTS_CHECK","GOOD");
        nerdLauncherFragment.setArguments(args);
        return nerdLauncherFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View v= inflater.inflate(R.layout.fragment_nerd_launcher,container,false);
        mRecyclerView = (RecyclerView) v.findViewById(R.id.fragment_nerd_launcher_recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        List<ResolveInfo> activities = setupLauncherActivity();
        if(mActivityAdapter == null) {
            mActivityAdapter = new ActivityAdapter(activities);
            mRecyclerView.setAdapter(mActivityAdapter);
        }
        else
        {
            mActivityAdapter.notifyDataSetChanged();
        }
        return v;
    }

    private List<ResolveInfo> setupLauncherActivity()
    {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        final PackageManager pm = getActivity().getPackageManager();
        List<ResolveInfo> list = pm.queryIntentActivities(intent,0);
        Collections.sort(list, new Comparator<ResolveInfo>() {
            @Override
            public int compare(ResolveInfo resolveInfo, ResolveInfo t1) {
                return String.CASE_INSENSITIVE_ORDER.compare(resolveInfo.loadLabel(pm).toString(),t1.loadLabel(pm).toString());
            }
        });
        return list;
    }

    private class ActivityHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        private TextView activityName;
        private ImageView activtyIcon;
        private ResolveInfo mResolveInfo;



        public ActivityHolder(View itemView) {
            super(itemView);
            activityName = (TextView) itemView.findViewById(R.id.textview);
            activtyIcon=(ImageView) itemView.findViewById(R.id.imageview);
            activityName.setOnClickListener(this);

        }

        public void BindActivityName(ResolveInfo resolveInfo)
        {
            mResolveInfo=resolveInfo;
            PackageManager pm = getActivity().getPackageManager();
            Drawable drawable=mResolveInfo.loadIcon(pm);
            String appName = mResolveInfo.loadLabel(pm).toString();
            activityName.setText(appName);
            activtyIcon.setImageDrawable(drawable);
        }

        @Override
        public void onClick(View view) {
            ActivityInfo activityInfo = mResolveInfo.activityInfo;
            Intent i =new Intent(Intent.ACTION_MAIN)
                    .setClassName(activityInfo.applicationInfo.packageName,activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);

        }
    }

    private class ActivityAdapter extends RecyclerView.Adapter<ActivityHolder>
    {
        List<ResolveInfo> mActivities;
        public ActivityAdapter(List<ResolveInfo> activities) {
            mActivities=activities;
        }

        @Override
        public ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            View view = layoutInflater.inflate(R.layout.activity_list_layout,parent,false);
            return new ActivityHolder(view);
        }

        @Override
        public void onBindViewHolder(ActivityHolder holder, int position) {
            ResolveInfo resolveInfo = mActivities.get(position);
            holder.BindActivityName(resolveInfo);
        }

        @Override
        public int getItemCount() {
            return mActivities.size();
        }
    }


}
