package com.example.abtiwari.listviewexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

private ListView tv_shows;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] tvshows = {"Pushing Daisies", "Better Off Ted", "Twin Peaks", "Freaks and Geeks", "Orphan Black",
                "Walking Dead", "Breaking Bad", "The 400", "Alphas", "Life on Mars"};
        tv_shows=(ListView)findViewById(R.id.list1);

       ListAdapter listAdapter=new MyAdapter(this,tvshows);
        tv_shows.setAdapter(listAdapter);

        tv_shows.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                String itemSelected = "You Selected "+String.valueOf(adapterView.getItemAtPosition(position));
                Toast.makeText(MainActivity.this, itemSelected, Toast.LENGTH_SHORT).show();
            }
        });


    }
}
