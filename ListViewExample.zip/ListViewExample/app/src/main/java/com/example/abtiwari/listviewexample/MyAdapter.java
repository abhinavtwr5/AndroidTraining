package com.example.abtiwari.listviewexample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public  class MyAdapter extends ArrayAdapter<String> {
    public MyAdapter( Context context, String[] tvshows) {
        super(context,R.layout.row_layout_2, tvshows);
    }


    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {

        LayoutInflater theInflater= LayoutInflater.from(getContext());
        View theview=theInflater.inflate(R.layout.row_layout_2,parent,false);

        String item= getItem(position);

        TextView textView=(TextView) theview.findViewById(R.id.textview1);
        textView.setText(item);

        ImageView imgview=(ImageView) theview.findViewById(R.id.imgview1);
        imgview.setImageResource(R.drawable.soft_wave_background_310823);

        return theview;

    }
}
