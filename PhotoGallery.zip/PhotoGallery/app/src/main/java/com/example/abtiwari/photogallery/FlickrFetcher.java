package com.example.abtiwari.photogallery;

import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class FlickrFetcher {

    private static final String TAG = "FlickrFetchr";
    private static final String API_KEY = "547d486bd19658fe0790a77ca11fb5a3";
    private static final String FETCH_RECENTS_METHOD = "flickr.photos.getRecent";
    private static final String SEARCH_METHOD = "flickr.photos.search";
    private static final Uri ENDPOINT = Uri.parse("https://api.flickr.com/services/rest/")
            .buildUpon()
            .appendQueryParameter("api_key", API_KEY)
            .appendQueryParameter("format", "json")
            .appendQueryParameter("nojsoncallback", "1")
            .appendQueryParameter("extras", "url_s").build();


    public byte[] getUrlData(String urlSpec) throws IOException
    {
        URL url = new URL(urlSpec);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            httpURLConnection.setDoOutput(true);
            InputStream in = httpURLConnection.getInputStream();
            if (httpURLConnection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException(httpURLConnection.getResponseMessage() + ": with " + urlSpec);
            }
            int length = 0;
            byte[] buffer = new byte[1024];
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            out.close();
            return out.toByteArray();

        }  finally {
                httpURLConnection.disconnect();
            }
    }

    public String getUrlString(String urlSpec) throws IOException
    {
        byte[] urlData = getUrlData(urlSpec);
        return new String(urlData);
    }

    public List<GalleryItems> fetchRecentPhotos()
    {
        String url =BuildUrl(FETCH_RECENTS_METHOD,null);
        Log.i(TAG,url);
        return downloadgalleryItems(url);
    }
    public List<GalleryItems> searchPhotos(String query)
    {
        String url = BuildUrl(SEARCH_METHOD,query);
        Log.i(TAG,url);
        return downloadgalleryItems(url);
    }

    private List<GalleryItems> downloadgalleryItems(String url)
    {
        List<GalleryItems> ItemsList = new ArrayList<>();
        try
        {
            String jsonString = getUrlString(url);
            Log.i(TAG,jsonString);
            JSONObject jsonBody = new JSONObject(jsonString);
            parseItems(ItemsList,jsonBody);
        }
        catch (Exception ioe)
        {
            Log.e(TAG, "Failed to fetch items", ioe);
        }
        Log.i(TAG,ItemsList.get(0).getUrl().toString());
        return ItemsList;

    }

    private String BuildUrl(String method, String query)
    {
        Uri.Builder builder = ENDPOINT.buildUpon()
                .appendQueryParameter("method",method);

        if(method.equals(SEARCH_METHOD))
        {
            builder.appendQueryParameter("text",query);
        }
        return builder.build().toString();
    }


    private void parseItems(List<GalleryItems> ItemsList, JSONObject jsonBody) throws JSONException {


            JSONObject photosjsonObject = jsonBody.getJSONObject("photos");
           // Log.i("JSON_STRING",photosjsonObject.toString());
        JSONArray photoArray = photosjsonObject.getJSONArray("photo");
       // Log.i("JSON_STRING",photoArray.toString());
        for(int i=0;i<photoArray.length();i++)
        {
            JSONObject photoDetails = photoArray.getJSONObject(i);
            GalleryItems item = new GalleryItems();

            String id = photoDetails.getString("id");
            String title = photoDetails.getString("title");
            String owner = photoDetails.getString("owner");
            item.setId(id);
            item.setCaption(title);
            item.setOwner(owner);

            if(!photoDetails.has("url_s"))
            {
                continue;
            }
            String urls =photoDetails.getString("url_s");
            item.setUrl(urls);
            ItemsList.add(item);
        }

    }

}
