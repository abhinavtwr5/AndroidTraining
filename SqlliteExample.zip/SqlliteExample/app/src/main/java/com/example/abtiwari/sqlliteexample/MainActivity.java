package com.example.abtiwari.sqlliteexample;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase contactsDB=null;
    Button create_database,delete_database,add_contact,get_contact,delete_contact;
    EditText name,phone,email,delete_id;
    TextView showContacts;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        create_database=(Button) findViewById(R.id.create_database);
        delete_database=(Button) findViewById(R.id.delete_database);
        add_contact=(Button) findViewById(R.id.add_contact);
        get_contact=(Button) findViewById(R.id.get_contact);
        delete_contact=(Button) findViewById(R.id.delete_contact);

        name=(EditText) findViewById(R.id.name);
        phone=(EditText) findViewById(R.id.phone);
        email=(EditText) findViewById(R.id.email);
        delete_id=(EditText) findViewById(R.id.delete_id);

        showContacts=(TextView) findViewById(R.id.showContacts);


    }

    public void CreateDatabase(View view) {


        try {
            contactsDB = this.openOrCreateDatabase("MyContacts", MODE_PRIVATE, null);
            contactsDB.execSQL("CREATE TABLE contacts " +
                    "(id integer PRIMARY KEY NOT NULL,name VARCHAR,phone VARCHAR,email VARCHAR);");

            File database = getApplicationContext().getDatabasePath("MyContacts");
            if (database.exists()) {
                Toast.makeText(this, "DataBase Created Successfully", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e)
        {
            Log.v("ERROR","ERROR CREATING DATABASE");
        }

        delete_database.setClickable(true);
        add_contact.setClickable(true);
        delete_contact.setClickable(true);
        get_contact.setClickable(true);
    }

    public void AddContact(View view) {

        String person_name=name.getText().toString();
        String mobile_no=phone.getText().toString();
        String email_id=email.getText().toString();

        Log.v("AVJVJHJHJHG",email_id);
        contactsDB.execSQL("INSERT INTO contacts (name,phone,email) VALUES ('"+person_name+"','"+mobile_no+"','"+email_id+"');");
    }

    public void GetContact(View view) {

        Cursor cursor = contactsDB.rawQuery("SELECT * FROM contacts",null);
        int idCol=cursor.getColumnIndex("id");
        int nameCol=cursor.getColumnIndex("name");
        int phoneCol=cursor.getColumnIndex("phone");
        int emailCol=cursor.getColumnIndex("email");
        String contactList="";

        cursor.moveToFirst();


       if((cursor!=null)&&(cursor.getCount()>0)) {
           do {
               int id = cursor.getInt(idCol);
               String person_name = cursor.getString(nameCol);
               String mobile_no = cursor.getString(phoneCol);
               String email_id = cursor.getString(emailCol);

               Log.v("NAME", person_name);

               contactList = contactList + id + ".) " + " " + person_name + "\n" + mobile_no + "\n" + email_id + "\n\n";
               Log.v("contactList", contactList);
           } while (cursor.moveToNext());

           showContacts.setText(contactList);
       }
       else
       {
           showContacts.setText("");
           Toast.makeText(this, "No contacts to show", Toast.LENGTH_SHORT).show();
       }

    }

    public void DeleteContact(View view) {

        String idToDelete =delete_id.getText().toString();


        if(delete_id.getText().toString().trim().length()==0)
        {
            Toast.makeText(this, "Please Enter an id", Toast.LENGTH_SHORT).show();
        }
        else
        {
            contactsDB.execSQL("DELETE FROM contacts WHERE id = "+ idToDelete+";");
        }

    }

    public void DeleteDatabase(View view) {

        this.deleteDatabase("MyContacts");
        Toast.makeText(this, "DataBase Deleted Successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {

        contactsDB.close();
        super.onDestroy();
    }
}
