package com.example.abtiwari.sharedpreferences;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.PersistableBundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText notesEdit;
    Button settings;
    private final static int SETTING_INFO=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notesEdit=(EditText)findViewById(R.id.editText);

        if(savedInstanceState!=null)
        {
            String notes=savedInstanceState.getString("NOTES");
            notesEdit.setText(notes);
        }

        String notes=getPreferences(Context.MODE_PRIVATE).getString("NOTES","EMPTY");

        if(!notes.equals("EMPTY"))
        {
            notesEdit.setText(notes);
        }

        settings=(Button)findViewById(R.id.button);

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),SettingsActivity.class);
                startActivityForResult(intent,SETTING_INFO);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==SETTING_INFO)
        {
            updateNotesText();
        }
    }

    private void updateNotesText()
    {
        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        if(sharedPreferences.getBoolean("pref_text_bold",false))
        {
            notesEdit.setTypeface(null,Typeface.BOLD);
        }
        else
        {
            notesEdit.setTypeface(null,Typeface.NORMAL);
        }

        String txtSize=sharedPreferences.getString("pref_text_size","10");
        float f=Float.parseFloat(txtSize);
        notesEdit.setTextSize(f);

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        outState.putString("NOTES",
                notesEdit.getText().toString());
        super.onSaveInstanceState(outState);

    }

    private void saveSettings()
    {
        SharedPreferences.Editor spEditor=getPreferences(Context.MODE_PRIVATE).edit();
        spEditor.putString("NOTES",notesEdit.getText().toString());
        spEditor.commit();
    }

    @Override
    protected void onStop() {
        saveSettings();
        super.onStop();
    }
}
