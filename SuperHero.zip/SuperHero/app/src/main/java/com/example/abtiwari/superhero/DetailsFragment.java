package com.example.abtiwari.superhero;


import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.TextView;

public class DetailsFragment extends Activity{

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_layout);
        Intent data = getIntent();
        int pos = data.getExtras().getInt("index");
        TextView txt = (TextView)findViewById(R.id.text);
        txt.setText(SuperHeroInfo.HISTORY[pos]);

    }

}
