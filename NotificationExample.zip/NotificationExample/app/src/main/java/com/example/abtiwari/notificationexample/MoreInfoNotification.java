package com.example.abtiwari.notificationexample;

import android.app.Activity;
import android.os.Bundle;

// Called when the notification is clicked on in the task bar
public class MoreInfoNotification extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.more_info_notific);
    }
}
