package com.example.abtiwari.jsonparserexample;

import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    EditText wordstoTranslate;
    Button translateButton;
    TextView showText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Translate(View view) {

        wordstoTranslate = (EditText) findViewById(R.id.wordstoTranslate);
        if (!isEmpty(wordstoTranslate)) {

            Toast.makeText(getApplicationContext(), "Translating....", Toast.LENGTH_LONG).show();
            String words = wordstoTranslate.getText().toString();
            new translating().execute(words);
        } else {
            Toast.makeText(this, "Enter the words to translate", Toast.LENGTH_SHORT).show();
            localJson();
        }
    }

    protected boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().length() == 0;
    }

    class translating extends AsyncTask<String, Void, Void> {
        String jsonString = "";
        String result = "";

        @Override
        protected Void doInBackground(String... strings) {

            String words = strings[0];
            words = words.replace(" ", "+");
            URL url;
            HttpURLConnection urlConnection = null;
            try {
                url = new URL("http://newjustin.com/translateit.php?action=translations&english_words=" + words);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }
                jsonString = sb.toString();
                Log.v("JSON_STRING", jsonString);
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONArray jsonArray = jsonObject.getJSONArray("translations");

                result = translateAndDisplay(jsonArray);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            showText = (TextView) findViewById(R.id.showText);
            showText.setText(result);
            super.onPostExecute(aVoid);
        }
    }

    public String translateAndDisplay(JSONArray jsonArray) {
        String language[] = {"arabic", "chinese", "danish", "dutch",
                "french", "german", "italian", "portuguese", "russian",
                "spanish"};
        String json = "";
        try {

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                json = json + language[i] + " : " + jsonObject.getString(language[i]) + "\n";

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.v("RESULT", json);

        return json;
    }


    protected void localJson() {
        try {

            InputStream inputStream = getAssets().open("parseJson.json");
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            String jsonString = sb.toString();
            Log.v("JSON_STRING FROM ASSETS", jsonString);
            try {
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONArray jsonArray = jsonObject.getJSONArray("translations");

                String result = translateAndDisplay(jsonArray);
                showText=(TextView)findViewById(R.id.showText);
                showText.setText(result);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
