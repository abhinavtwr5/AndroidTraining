package com.example.abtiwari.xmlpullparserexample;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    EditText wordstoTranslate;
    Button translateButton;
    TextView showText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Translate(View view) {

        wordstoTranslate = (EditText) findViewById(R.id.wordstoTranslate);
        if(!isEmpty(wordstoTranslate))
        {

            Toast.makeText(getApplicationContext(),"Translating....",Toast.LENGTH_SHORT).show();
            String words=wordstoTranslate.getText().toString();
            new translating().execute(words);
        }
        else
        {
            Toast.makeText(this, "Enter the words to translate", Toast.LENGTH_SHORT).show();
            localXml();
        }

    }

    protected boolean isEmpty(EditText editText)
    {
        return editText.getText().toString().trim().length()==0;
    }

    class translating extends AsyncTask<String,Void,Void>
    {
        String XmlString="";
        String result="";



        @Override
        protected Void doInBackground(String... strings) {

            String words=strings[0];
            words=words.replace(" ","+");
            URL url;
            HttpURLConnection urlConnection= null;
            try {
                url = new URL("http://newjustin.com/translateit.php?action=xmltranslations&english_words=" + words);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }
                XmlString = sb.toString();
                Log.v("XML_STRING", XmlString);
                result=Xmltranslator(XmlString);
                Log.v("RESULT",result);
            }
                 catch(IOException e){
                    e.printStackTrace();
                }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            showText = (TextView)findViewById(R.id.showText);
            Log.v("RESULT",result);
            showText.setText(result);
            super.onPostExecute(aVoid);
        }
    }

    public String Xmltranslator(String XmlString)
    {
        String result="";

        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new StringReader(XmlString));

            int eventType = xmlPullParser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && (!xmlPullParser.getName().equals("translations"))) {
                    result = result + xmlPullParser.getName() + " : ";
                } else if (eventType == XmlPullParser.TEXT) {
                    result = result + xmlPullParser.getText() + "\n";
                }
                eventType = xmlPullParser.next();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        return result;
    }



    protected void localXml()
    {
        try{
            InputStream inputStream = getAssets().open("parseXml.xml");
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"),8);
            StringBuilder sb = new StringBuilder();
            String line=null;
            while((line=br.readLine())!=null)
            {
                sb.append(line+"\n");
            }
            String Xml=sb.toString();
            Log.v("LOCALXML",Xml);
            String result_1=Xmltranslator(Xml);
            showText = (TextView)findViewById(R.id.showText);
            showText.setText(result_1);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

